package com.smarthire.model;

public enum Role {
    JOB_SEEKER,
    RECRUITER,
    ADMIN
}
