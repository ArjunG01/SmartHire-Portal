package com.smarthire.model;

public enum ApplicationStatus {
    PENDING,
    ACCEPTED,
    REJECTED
}
